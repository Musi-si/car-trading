import React from "react";

const Insert = () => {

    const [ price, setPrice ] = React.useState( 1000 );

    const increasePrice = () => {
        let newPrice = price;
        newPrice += 1000
        setPrice( newPrice );
    }

    const decreasePrice = () => {
        let newPrice = price;
        newPrice -= 1000
        setPrice( newPrice );
    }

    return (
        <div>
            <button className="short">$ { price } and above</button><button onClick = { increasePrice } className="price">{ '+' }</button><button onClick = { decreasePrice } className="price">{ '-' }</button><br />
        </div>
    )

}
export default Insert;
