import React from "react";
import './home.css';

const Car = () => {

    let option1 = 'Excellent', option2 = 'Good', option3 = 'Fair', option4 = 'Poor';
    let choice1 = 'Air Conditioning', choice2 = 'Power Steering', choice3 = 'Power Windows', choice4 = 'ABS', choice5 = 'Navigation System';
    let trans1 = 'Automatic', trans2 = 'Manual';

    // const [ maker, setMaker ] = React.useState( '' );
    // const [ model, setModel ] = React.useState( '' );
    // const [ date, setDate ] = React.useState( '' );
    // const [ mileage, setMileage ] =React.useState( '' );
    const [ radio, setRadio ] = React.useState( '' );
    const [ checkbox, setCheckbox ] = React.useState( '' );
    const [ option, setOption ] = React.useState( '' );
    // const [ price, setPrice ] = React.useState( '' );
    // const [ number, setNumber ] = React.useState();

    // const changeMaker = (event) => {
    //     // event.preventDefault();
    //     setMaker(event.target.value);
    //     console.log(maker);
    // }

    const insertData = ( event ) => {
        event.preventDefault();
        // setMaker( event.target.value );
        // setModel( event.target.value );
        // setDate( event.target.value );
        // setMileage( event.target.value );
        // setPrice( event.target.value );
        // setNumber( event.target.value );

        // console.log( maker );
        // console.log( model );
        // console.log( date );
        // console.log( mileage );
        console.log( radio );
        console.log( checkbox );
        console.log( option );
        // console.log( price );
        // console.log( number );
    }

    const changeRadio = ( event ) => {
        setRadio( event.target.value );
    }

    const changeCheckbox = ( event ) => {
        setCheckbox( event.target.value );
    }

    const changeOption = ( event ) => {
        setOption( event.target.value );
    }

    return (
        <div className="main">
            <h1>Motors</h1>
            <p id="title">CAR TRADING</p>
            <form className="info">
                <label htmlFor="maker">Car Maker:</label><br />
                <input type="text" className="input" /><br />
                <label htmlFor="model">Car Model:</label><br />
                <input type="text" className="input" /><br />
                <label htmlFor="year">Date of Release:</label><br />
                <input type="month" className="short" id="date" /><br />
                <label htmlFor="mileage">Mileage:</label><br />
                <input type="number" className="short" id="mileage" /><br />
                <label htmlFor="condition">Condition:</label><br/>
                <input type="radio" value = { option1 } checked = { radio === option1 } onChange = { changeRadio } />{ option1 }<br />
                <input type="radio" value = { option2 } checked = { radio === option2 } onChange = { changeRadio } />{option2}<br />
                <input type="radio" value = { option3 } checked = { radio === option3 } onChange = { changeRadio } />{option3}<br />
                <input type="radio" value = { option4 } checked = { radio === option4 } onChange = { changeRadio } />{option4}<br />
                <label htmlFor="features">Features:</label><br />
                <input type="checkbox" value = { choice1 } checked = { checkbox === choice1 } onChange = { changeCheckbox } />{choice1}<br />
                <input type="checkbox" value = { choice2 } checked = { checkbox === choice2 } onChange = { changeCheckbox } />{choice2}<br />
                <input type="checkbox" value = { choice3 } checked = { checkbox === choice3 } onChange = { changeCheckbox } />{choice3}<br />
                <input type="checkbox" value = { choice4 } checked = { checkbox === choice4 } onChange = { changeCheckbox } />{choice4}<br />
                <input type="checkbox" value = { choice5 } checked = { checkbox === choice5 } onChange = { changeCheckbox } />{choice5}<br />
                <label htmlFor="transmission">Transmission:</label><br />
                <select value = { option } onChange = { changeOption } className="short">
                    <option value = { trans1 }>{ trans1 }</option>
                    <option value = { trans2 }>{ trans2 }</option>
                </select><br />
                <label htmlFor="price">Price Range:</label><br />
                <input type="range" minLength={ 1000 } maxLength={ 10000000 } className="price" /><br />
                <label htmlFor="contacts">Contact Number:</label><br />
                <input type="text" className="input" /><br />
                <button type="submit" className="short" id="submit" onSubmit = { insertData }>Submit</button>
            </form>
        </div>
    )
}

export default Car;
